-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 09, 2019 at 11:58 PM
-- Server version: 5.7.28-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `telegra3_instafollow`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` int(11) NOT NULL,
  `user` text COLLATE utf8_persian_ci NOT NULL,
  `pass` text COLLATE utf8_persian_ci NOT NULL,
  `email` text COLLATE utf8_persian_ci NOT NULL,
  `f_name` text COLLATE utf8_persian_ci,
  `city` text COLLATE utf8_persian_ci NOT NULL,
  `phone` text COLLATE utf8_persian_ci NOT NULL,
  `device` text COLLATE utf8_persian_ci NOT NULL,
  `token` text COLLATE utf8_persian_ci NOT NULL,
  `instagram` int(11) NOT NULL DEFAULT '0',
  `telegram` int(11) DEFAULT '0',
  `ads` int(11) DEFAULT '0',
  `vip` int(11) NOT NULL DEFAULT '0',
  `ip` text COLLATE utf8_persian_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `list_user`
--

CREATE TABLE `list_user` (
  `id` int(11) NOT NULL,
  `user` text COLLATE utf8_persian_ci NOT NULL,
  `pass` text COLLATE utf8_persian_ci NOT NULL,
  `id_user` text COLLATE utf8_persian_ci,
  `coin_f` int(11) DEFAULT NULL,
  `coin_l` int(11) NOT NULL,
  `coin_c` int(11) NOT NULL,
  `fullname` text COLLATE utf8_persian_ci,
  `pic` text COLLATE utf8_persian_ci,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` text COLLATE utf8_persian_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `l_ads`
--

CREATE TABLE `l_ads` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `types` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL,
  `url` text COLLATE utf8_persian_ci NOT NULL,
  `num_see` int(11) NOT NULL DEFAULT '0',
  `num_users` int(11) NOT NULL,
  `is_ads` int(11) NOT NULL DEFAULT '0',
  `is_vip` int(11) NOT NULL DEFAULT '0',
  `socia` int(11) NOT NULL,
  `is_ok` int(11) NOT NULL DEFAULT '0',
  `price` varchar(40) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  `pic` int(11) NOT NULL,
  `t1` int(11) NOT NULL,
  `t2` int(11) NOT NULL,
  `t_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `t_make` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `l_insta`
--

CREATE TABLE `l_insta` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `userid` text COLLATE utf8_persian_ci NOT NULL,
  `username` text COLLATE utf8_persian_ci NOT NULL,
  `pass` text COLLATE utf8_persian_ci NOT NULL,
  `c_f` int(11) NOT NULL DEFAULT '15',
  `c_m` int(11) NOT NULL DEFAULT '15',
  `pic` text COLLATE utf8_persian_ci NOT NULL,
  `phone` text COLLATE utf8_persian_ci NOT NULL,
  `token` text COLLATE utf8_persian_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip` text COLLATE utf8_persian_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `l_tele`
--

CREATE TABLE `l_tele` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `userid` text NOT NULL,
  `username` text NOT NULL,
  `first_last` text NOT NULL,
  `phone` text NOT NULL,
  `c_ch` int(11) NOT NULL DEFAULT '15',
  `c_m` int(11) NOT NULL DEFAULT '15',
  `times` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip` text CHARACTER SET utf8 COLLATE utf8_persian_ci,
  `token` text CHARACTER SET utf8 COLLATE utf8_persian_ci
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `l_tele`
--

INSERT INTO `l_tele` (`id`, `uid`, `userid`, `username`, `first_last`, `phone`, `c_ch`, `c_m`, `times`, `ip`, `token`) VALUES
(1, 1, '938022689', 'Di4ku', 'Milad_', '+989172235561', 150000, 19700, '2019-12-09 20:27:13', '54.38.23.202', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `pay_list`
--

CREATE TABLE `pay_list` (
  `id` int(11) NOT NULL,
  `price` text COLLATE utf8_persian_ci NOT NULL,
  `t_old` text COLLATE utf8_persian_ci NOT NULL,
  `t_new` text COLLATE utf8_persian_ci NOT NULL,
  `name` text COLLATE utf8_persian_ci NOT NULL,
  `x` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `pay_list`
--

INSERT INTO `pay_list` (`id`, `price`, `t_old`, `t_new`, `name`, `x`) VALUES
(7, '5000', '150', '250', 'coin_f250', 'follow'),
(2, '1000', '50', '100', 'coin_l100', 'like'),
(3, '3000', '150', '250', 'coin_l250', 'like'),
(4, '5000', '300', '500', 'coin_l500', 'like'),
(5, '8500', '700', '1000', 'coin_l1000', 'like'),
(6, '2000', '50', '100', 'coin_f100', 'follow'),
(8, '8500', '400', '500', 'coin_f500', 'follow'),
(9, '12000', '500', '1000', 'coin_f1000', 'follow');

-- --------------------------------------------------------

--
-- Table structure for table `req_ads`
--

CREATE TABLE `req_ads` (
  `id` int(11) NOT NULL,
  `uid` text NOT NULL,
  `description` text NOT NULL,
  `url` text NOT NULL,
  `pic` text NOT NULL,
  `r_t` text NOT NULL,
  `rt` text NOT NULL,
  `re` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sef_insta`
--

CREATE TABLE `sef_insta` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `userid` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `types` int(11) NOT NULL,
  `target` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `start` int(11) NOT NULL DEFAULT '0',
  `finish` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `token` text COLLATE utf8_persian_ci NOT NULL,
  `times` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `imgpost` text COLLATE utf8_persian_ci,
  `codes` varchar(150) COLLATE utf8_persian_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sef_tele`
--

CREATE TABLE `sef_tele` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `userid` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `chat_id` text COLLATE utf8_persian_ci NOT NULL,
  `msg_id` text COLLATE utf8_persian_ci NOT NULL,
  `start` int(11) NOT NULL DEFAULT '0',
  `finish` int(11) NOT NULL,
  `njob` text COLLATE utf8_persian_ci NOT NULL,
  `types` text COLLATE utf8_persian_ci NOT NULL,
  `token` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `times` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pic` text COLLATE utf8_persian_ci,
  `status` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `sef_tele`
--

INSERT INTO `sef_tele` (`id`, `uid`, `userid`, `chat_id`, `msg_id`, `start`, `finish`, `njob`, `types`, `token`, `times`, `pic`, `status`) VALUES
(1, 1, '160460920', 'padokar_ir', '0', 5, 50, '0', '1', '73ejf6bfizor0sw', '2018-10-16 07:00:59', 'http://filework.ir/INSTAFOLLOW/api/telepic/183331.jpg', 0),
(2, 1, '160460920', 'akhbar_montakhab', '0', 4, 50, '0', '1', '3rlxhmsgledc8hb', '2018-10-16 07:01:31', 'http://filework.ir/INSTAFOLLOW/api/telepic/65071.jpg', 0),
(3, 1, '160460920', 'Sakhteiranseryal', '0', 5, 50, '0', '1', 'thgfpw0gpdmb0bz', '2018-10-16 07:01:43', 'http://filework.ir/INSTAFOLLOW/api/telepic/201314.jpg', 0),
(4, 1, '160460920', 'akhbarefori', '0', 6, 50, '0', '1', 'cm2i7gmqmgdbsvn', '2018-10-16 07:02:22', 'http://filework.ir/INSTAFOLLOW/api/telepic/194356.jpg', 0),
(5, 1, '160460920', 'dastan_kootah', '0', 6, 50, '0', '1', 'l6j47spyayq2vzs', '2018-10-16 07:06:32', 'http://filework.ir/INSTAFOLLOW/api/telepic/noimage.png', 0),
(6, 1, '160460920', 'phdiran', '0', 4, 50, '0', '1', 'qgzqm5m3ckmb7jt', '2018-10-16 07:06:59', 'http://filework.ir/INSTAFOLLOW/api/telepic/102000.jpg', 0),
(7, 1, '160460920', 'phdiran', '0', 5, 50, '0', '1', 'mim3vhpxube800v', '2018-10-16 07:07:13', 'http://filework.ir/INSTAFOLLOW/api/telepic/noimage.png', 0),
(8, 1, '160460920', 'kafiha', '0', 4, 50, '0', '1', 'wm61ony7y0qmstv', '2018-10-16 07:19:41', 'http://filework.ir/INSTAFOLLOW/api/telepic/noimage.png', 0),
(25, 1, '160460920', '-1001017058834', '3988783104', 2, 50, 'linkdoonii', '2', '1f6hbojbsee8ncg', '2018-10-16 10:40:11', 'http://filework.ir/INSTAFOLLOW/api/telepic/89120.jpg', 0),
(26, 1, '160460920', '-1001004069147', '147741212672', 3, 50, 'akhbarefori', '2', 'lt7tljh8iuhtlsb', '2018-10-16 11:18:25', 'http://filework.ir/INSTAFOLLOW/api/telepic/194356.jpg', 0),
(27, 1, '160460920', '-1001017058834', '3988783104', 2, 50, 'linkdoonii', '2', 'wdtje80tpa9ocri', '2018-10-16 15:05:27', 'http://filework.ir/INSTAFOLLOW/api/telepic/89120.jpg', 0),
(28, 1, '160460920', '-1001056098828', '89980403712', 2, 50, 'shadab_dance', '2', 'z2jq7avothqd0ve', '2018-10-16 15:06:45', 'http://filework.ir/INSTAFOLLOW/api/telepic/48717.jpg', 0),
(29, 1, '222482415', '-1001017058834', '3988783104', 3, 50, 'linkdoonii', '2', 'pz2zfi7p3jetdza', '2018-10-16 15:45:08', 'http://filework.ir/INSTAFOLLOW/api/telepic/89120.jpg', 0),
(30, 1, '160460920', '-1001017058834', '10032775168', 1, 50, 'linkdoonii', '2', 'tcr93gw35jnuj7q', '2018-10-24 11:47:57', 'http://filework.ir/INSTAFOLLOW/api/telepic/noimage.png', 0),
(31, 1, '160460920', 'pgming', '0', 2, 50, '0', '1', 'roi7flcfczaecg0', '2018-11-06 09:19:25', 'http://filework.ir/INSTAFOLLOW/api/telepic/245693.jpg', 0),
(32, 1, '160460920', 'pgming', '0', 3, 100, '0', '1', '5bgvlbf9lmik03d', '2018-11-06 09:19:43', 'http://filework.ir/INSTAFOLLOW/api/telepic/245693.jpg', 0),
(33, 1, '938022689', '-1001140894927', '82451628032', 0, 50, 'linkdoni', '2', 'g4csz026t37e2v5', '2019-12-09 12:48:03', 'http://filework.ir/INSTAFOLLOW/api/telepic/37905.jpg', 0),
(34, 1, '938022689', '-1001000010898', '1561329664', 0, 50, 'quicklearn', '2', 'z3t76wau65hjmwk', '2019-12-09 12:57:13', 'http://filework.ir/INSTAFOLLOW/api/telepic/122354.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hispay`
--

CREATE TABLE `tbl_hispay` (
  `id` int(11) NOT NULL,
  `typesef` int(11) NOT NULL,
  `user_id` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `username` text COLLATE utf8_persian_ci,
  `nums` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `prices` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_hispay`
--

INSERT INTO `tbl_hispay` (`id`, `typesef`, `user_id`, `username`, `nums`, `prices`, `time`) VALUES
(1, 1, '113212', 'milad', '10', '10000', '2018-10-06 06:15:06'),
(2, 0, '2894270461', 'milady4r', '100', '1000', '2018-10-06 06:26:20'),
(3, 0, '6989165846', 'bazartest', '100', '1000', '2018-11-26 10:16:12'),
(4, 0, '8893158554', 'hamed__sobhani__', '1000', '10000', '2018-11-28 07:56:08'),
(5, 0, '5783025975', 'ali_turkk20', '100', '1000', '2018-11-28 15:12:26'),
(6, 0, '5783025975', 'ali_turkk20', '100', '1000', '2018-11-28 15:12:38'),
(7, 0, '5783025975', 'ali_turkk20', '100', '1000', '2018-11-28 15:13:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ip`
--

CREATE TABLE `tbl_ip` (
  `id` int(11) NOT NULL,
  `ip` text COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_ip`
--

INSERT INTO `tbl_ip` (`id`, `ip`, `status`, `time`) VALUES
(1, '192.168.1.1', 1, '2018-10-06 16:37:16'),
(2, '192.3.02.02', 1, '2018-10-06 06:07:29'),
(3, '136.0.99.51', 1, '2018-10-06 09:57:56'),
(4, '95.64.124.67', 1, '2018-10-09 01:42:38'),
(5, '2.177.89.111', 1, '2018-10-09 03:26:22'),
(6, '5.216.255.120', 1, '2018-10-09 07:08:46'),
(7, '95.216.199.192', 1, '2018-10-09 07:22:15'),
(8, '95.216.164.77', 1, '2018-10-09 09:03:04'),
(9, '77.42.80.162', 1, '2018-10-09 09:23:34'),
(10, '5.213.179.118', 1, '2018-10-09 11:32:25'),
(11, '146.185.182.180', 1, '2018-10-09 12:07:59'),
(12, '158.58.76.2', 1, '2018-10-09 12:29:01'),
(13, '5.216.115.5', 1, '2018-10-09 12:34:20'),
(14, '178.128.198.32', 1, '2018-10-09 12:37:02'),
(15, '151.234.51.220', 1, '2018-10-09 13:02:39'),
(16, '146.185.160.61', 1, '2018-10-09 13:13:37'),
(17, '188.166.10.174', 1, '2018-10-09 13:33:39'),
(18, '158.58.64.93', 1, '2018-10-09 13:37:54'),
(19, '5.120.41.78', 1, '2018-10-09 13:42:45'),
(20, '159.89.3.110', 1, '2018-10-09 16:31:24'),
(21, '5.212.1.82', 1, '2018-10-09 16:48:38'),
(22, '46.51.86.84', 1, '2018-10-09 17:22:04'),
(23, '128.199.161.189', 1, '2018-10-09 17:23:33'),
(24, '146.185.139.189', 1, '2018-10-09 17:34:39'),
(25, '5.212.83.132', 1, '2018-10-10 04:14:11'),
(26, '163.172.70.50', 1, '2018-10-10 09:49:18'),
(27, '37.129.88.132', 1, '2018-10-10 10:20:41'),
(28, '151.234.55.81', 1, '2018-10-10 12:41:38'),
(29, '159.89.27.57', 1, '2018-10-10 15:11:26'),
(30, '83.123.120.159', 1, '2018-10-10 17:20:46'),
(31, '173.249.55.160', 1, '2018-10-10 17:49:39'),
(32, '51.15.106.95', 1, '2018-10-10 17:59:09'),
(33, '5.214.90.206', 1, '2018-10-10 18:02:18'),
(34, '51.15.38.246', 1, '2018-10-10 18:07:54'),
(35, '195.201.37.176', 1, '2018-10-11 10:10:02'),
(36, '151.232.182.33', 1, '2018-10-11 11:58:05'),
(37, '51.38.82.139', 1, '2018-10-11 16:54:47'),
(38, '46.224.73.161', 1, '2018-10-11 17:14:46'),
(39, '207.154.204.94', 1, '2018-10-11 19:17:55'),
(40, '5.218.244.40', 1, '2018-10-12 09:10:51'),
(41, '151.238.237.78', 1, '2018-10-12 11:06:00'),
(42, '45.33.80.50', 1, '2018-10-12 19:31:27'),
(43, '204.18.98.175', 1, '2018-10-12 19:39:28'),
(44, '93.126.40.13', 1, '2018-10-13 09:43:52'),
(45, '195.201.38.38', 1, '2018-10-13 09:54:04'),
(46, '69.194.109.18', 1, '2018-10-14 08:41:30'),
(47, '69.194.80.82', 1, '2018-10-14 12:35:39'),
(48, '5.210.177.162', 1, '2018-10-14 14:35:54'),
(49, '5.210.143.128', 1, '2018-10-14 16:46:17'),
(50, '146.185.139.114', 1, '2018-10-14 16:51:06'),
(51, '54.36.111.65', 1, '2018-10-14 17:02:38'),
(52, '163.172.67.20', 1, '2018-10-14 17:10:33'),
(53, '151.232.213.26', 1, '2018-10-15 19:53:09'),
(54, '5.214.161.22', 1, '2018-10-16 15:35:47'),
(55, '172.104.212.20', 1, '2018-10-16 18:54:14'),
(56, '172.104.218.230', 1, '2018-10-16 19:01:18'),
(57, '95.85.36.81', 1, '2018-10-16 22:18:53'),
(58, '5.123.55.60', 1, '2018-10-16 22:34:38'),
(59, '5.216.47.221', 1, '2018-10-17 03:29:00'),
(60, '151.233.217.84', 1, '2018-10-17 07:58:32'),
(61, '5.216.38.73', 1, '2018-10-17 10:32:14'),
(62, '5.119.138.140', 1, '2018-10-17 13:52:30'),
(63, '5.211.147.176', 1, '2018-10-17 14:04:32'),
(64, '172.104.17.41', 1, '2018-10-17 14:17:58'),
(65, '151.234.29.93', 1, '2018-10-17 19:24:14'),
(66, '5.211.36.128', 1, '2018-10-18 14:20:25'),
(67, '217.182.198.220', 1, '2018-10-18 17:58:32'),
(68, '46.224.97.132', 1, '2018-10-18 19:44:38'),
(69, '204.18.78.131', 1, '2018-10-18 19:48:18'),
(70, '204.18.39.41', 1, '2018-10-19 17:13:21'),
(71, '80.82.67.103', 1, '2018-10-20 08:08:01'),
(72, '5.210.20.180', 1, '2018-10-21 06:21:38'),
(73, '5.217.179.103', 1, '2018-10-21 20:00:34'),
(74, '2.182.243.154', 1, '2018-10-21 20:05:29'),
(75, '5.119.10.49', 1, '2018-10-22 16:12:31'),
(76, '5.218.95.241', 1, '2018-10-22 21:24:47'),
(77, '5.214.202.69', 1, '2018-10-22 21:31:13'),
(78, '5.122.245.161', 1, '2018-10-24 11:42:18'),
(79, '159.69.146.255', 1, '2018-10-24 11:46:22'),
(80, '5.216.213.159', 1, '2018-10-26 10:14:23'),
(81, '5.124.175.3', 1, '2018-10-27 08:36:47'),
(82, '5.124.242.138', 1, '2018-10-27 08:51:17'),
(83, '93.126.40.20', 1, '2018-10-27 09:06:22'),
(84, '83.147.236.54', 1, '2018-10-30 21:59:54'),
(85, '5.123.91.31', 1, '2018-11-06 08:56:22'),
(86, '159.69.147.0', 1, '2018-11-06 09:03:48'),
(87, '5.211.81.132', 1, '2018-11-06 09:24:33'),
(88, '83.147.232.182', 1, '2018-11-06 19:26:44'),
(89, '2.188.26.151', 1, '2018-11-06 20:29:17'),
(90, '83.122.67.155', 1, '2018-11-07 08:21:02'),
(91, '5.212.114.108', 1, '2018-11-08 18:09:17'),
(92, '5.202.46.69', 1, '2018-11-08 20:11:33'),
(93, '159.69.39.56', 1, '2018-11-08 23:14:59'),
(94, '198.98.57.71', 1, '2018-11-09 16:09:45'),
(95, '188.226.179.171', 1, '2018-11-09 16:32:58'),
(96, '89.196.165.112', 1, '2018-11-09 16:34:19'),
(97, '94.23.60.106', 1, '2018-11-09 16:37:03'),
(98, '159.69.126.231', 1, '2018-11-12 19:38:06'),
(99, '151.233.198.211', 1, '2018-11-13 07:22:44'),
(100, '178.32.88.234', 1, '2018-11-13 21:14:08'),
(101, '137.74.180.172', 1, '2018-11-13 21:20:50'),
(102, '151.234.52.67', 1, '2018-11-14 13:46:23'),
(103, '151.233.223.137', 1, '2018-11-14 20:33:37'),
(104, '192.95.22.73', 1, '2018-11-14 20:38:29'),
(105, '5.202.94.104', 1, '2018-11-15 00:19:38'),
(106, '79.137.62.29', 1, '2018-11-15 10:58:11'),
(107, '91.251.120.119', 1, '2018-11-18 17:42:53'),
(108, '91.251.247.131', 1, '2018-11-18 21:04:42'),
(109, '51.254.99.40', 1, '2018-11-18 21:17:27'),
(110, '51.15.45.113', 1, '2018-11-18 22:33:17'),
(111, '83.147.237.100', 1, '2018-11-19 10:23:07'),
(112, '146.185.154.81', 1, '2018-11-20 04:39:48'),
(113, '138.68.111.170', 1, '2018-11-22 20:54:57'),
(114, '5.123.169.150', 1, '2018-11-23 16:29:44'),
(115, '5.114.100.178', 1, '2018-11-24 10:52:32'),
(116, '151.232.66.98', 1, '2018-11-25 08:05:18'),
(117, '5.112.218.99', 1, '2018-11-26 10:15:29'),
(118, '5.214.232.31', 1, '2018-11-26 13:07:56'),
(119, '77.81.152.27', 1, '2018-11-26 13:09:11'),
(120, '5.217.194.17', 1, '2018-11-26 13:17:06'),
(121, '5.234.221.197', 1, '2018-11-26 13:57:07'),
(122, '190.2.152.129', 1, '2018-11-26 13:58:41'),
(123, '46.101.31.114', 1, '2018-11-26 16:09:13'),
(124, '207.154.247.171', 1, '2018-11-26 16:29:28'),
(125, '159.89.11.62', 1, '2018-11-26 16:53:42'),
(126, '5.219.8.188', 1, '2018-11-26 17:06:35'),
(127, '5.214.96.44', 1, '2018-11-26 17:26:06'),
(128, '93.117.97.232', 1, '2018-11-26 17:30:36'),
(129, '188.166.74.69', 1, '2018-11-26 18:28:16'),
(130, '5.219.1.5', 1, '2018-11-26 19:11:21'),
(131, '64.233.172.237', 1, '2018-11-26 19:21:26'),
(132, '5.189.145.93', 1, '2018-11-26 20:31:45'),
(133, '139.59.134.129', 1, '2018-11-26 20:57:29'),
(134, '5.75.84.90', 1, '2018-11-26 21:01:29'),
(135, '5.124.39.41', 1, '2018-11-26 21:34:16'),
(136, '93.115.228.170', 1, '2018-11-26 21:54:07'),
(137, '5.119.61.45', 1, '2018-11-26 23:20:12'),
(138, '37.237.199.49', 1, '2018-11-27 04:19:16'),
(139, '83.123.50.134', 1, '2018-11-27 05:09:10'),
(140, '188.136.149.33', 1, '2018-11-27 05:30:34'),
(141, '5.115.142.244', 1, '2018-11-27 08:54:16'),
(142, '5.219.226.219', 1, '2018-11-27 09:16:40'),
(143, '207.180.223.120', 1, '2018-11-27 09:49:26'),
(144, '192.99.211.207', 1, '2018-11-27 10:04:36'),
(145, '5.72.3.126', 1, '2018-11-27 10:06:30'),
(146, '149.56.140.128', 1, '2018-11-27 10:30:12'),
(147, '83.120.79.184', 1, '2018-11-27 11:04:42'),
(148, '5.117.167.198', 1, '2018-11-27 12:32:47'),
(149, '2.191.174.15', 1, '2018-11-27 12:48:25'),
(150, '66.160.178.51', 1, '2018-11-27 13:45:29'),
(151, '5.121.21.102', 1, '2018-11-27 14:31:56'),
(152, '69.194.119.172', 1, '2018-11-27 14:59:04'),
(153, '158.58.60.159', 1, '2018-11-27 15:44:18'),
(154, '188.158.240.104', 1, '2018-11-27 16:21:43'),
(155, '5.127.196.3', 1, '2018-11-27 17:11:30'),
(156, '95.64.119.95', 1, '2018-11-27 17:28:00'),
(157, '5.232.134.133', 1, '2018-11-27 17:34:54'),
(158, '5.116.136.224', 1, '2018-11-27 19:00:31'),
(159, '5.216.183.180', 1, '2018-11-27 19:04:34'),
(160, '89.249.67.196', 1, '2018-11-27 19:16:24'),
(161, '5.127.229.117', 1, '2018-11-27 19:34:03'),
(162, '5.216.46.170', 1, '2018-11-27 20:16:26'),
(163, '5.114.214.31', 1, '2018-11-27 20:43:13'),
(164, '5.127.204.77', 1, '2018-11-27 20:53:17'),
(165, '5.115.101.196', 1, '2018-11-27 22:22:47'),
(166, '184.154.62.27', 1, '2018-11-27 23:49:28'),
(167, '93.115.150.243', 1, '2018-11-28 00:30:16'),
(168, '5.121.90.127', 1, '2018-11-28 05:56:00'),
(169, '162.243.155.129', 1, '2018-11-28 06:20:52'),
(170, '5.119.18.45', 1, '2018-11-28 06:28:46'),
(171, '5.72.23.190', 1, '2018-11-28 07:51:38'),
(172, '5.126.168.31', 1, '2018-11-28 09:39:57'),
(173, '83.121.36.231', 1, '2018-11-28 10:17:43'),
(174, '2.191.41.78', 1, '2018-11-28 10:47:42'),
(175, '5.122.125.27', 1, '2018-11-28 12:19:23'),
(176, '5.119.235.108', 1, '2018-11-28 13:17:30'),
(177, '83.120.241.254', 1, '2018-11-28 13:28:43'),
(178, '5.120.63.182', 1, '2018-11-28 14:47:04'),
(179, '79.127.81.98', 1, '2018-11-28 14:49:48'),
(180, '5.121.163.160', 1, '2018-11-28 15:06:46'),
(181, '46.224.171.86', 1, '2018-11-28 16:03:51'),
(182, '95.162.85.195', 1, '2018-11-28 16:20:51'),
(183, '5.126.46.30', 1, '2018-11-28 16:35:48'),
(184, '46.41.218.116', 1, '2018-11-28 16:53:33'),
(185, '31.57.107.222', 1, '2018-11-28 18:56:01'),
(186, '5.121.146.4', 1, '2018-11-28 19:18:43'),
(187, '46.224.154.104', 1, '2018-11-28 19:22:34'),
(188, '5.124.179.160', 1, '2018-11-28 19:40:28'),
(189, '5.200.120.4', 1, '2018-11-28 19:51:14'),
(190, '5.121.181.27', 1, '2018-11-28 20:32:02'),
(191, '5.239.72.100', 1, '2018-11-28 20:44:47'),
(192, '172.80.246.189', 1, '2018-11-28 21:27:06'),
(193, '5.121.21.120', 1, '2018-11-28 21:49:18'),
(194, '5.121.118.233', 1, '2018-11-29 03:31:18'),
(195, '5.121.185.12', 1, '2018-11-29 04:08:10'),
(196, '192.15.25.146', 1, '2018-11-29 05:27:19'),
(197, '5.239.49.40', 1, '2018-11-29 05:34:10'),
(198, '5.121.96.176', 1, '2018-11-29 05:34:13'),
(199, '5.119.121.54', 1, '2018-11-29 05:56:33'),
(200, '5.121.32.95', 1, '2018-11-29 06:20:23'),
(201, '5.119.226.130', 1, '2018-11-29 06:32:05'),
(202, '5.122.39.8', 1, '2018-11-29 06:36:12'),
(203, '5.126.235.160', 1, '2018-11-29 06:43:25'),
(204, '5.116.150.250', 1, '2018-11-29 06:45:33'),
(205, '192.15.98.214', 1, '2018-11-29 06:53:19'),
(206, '95.64.81.23', 1, '2018-11-29 07:42:52'),
(207, '5.234.213.246', 1, '2018-11-29 08:12:29'),
(208, '5.124.233.157', 1, '2018-11-29 08:49:15'),
(209, '5.125.9.84', 1, '2018-11-29 09:12:50'),
(210, '5.125.238.67', 1, '2018-11-29 09:14:42'),
(211, '5.237.97.104', 1, '2018-11-29 09:25:51'),
(212, '192.15.74.158', 1, '2018-11-29 10:01:35'),
(213, '95.81.70.150', 1, '2018-11-29 10:17:58'),
(214, '5.121.249.127', 1, '2018-11-29 10:39:17'),
(215, '46.224.178.126', 1, '2018-11-29 11:08:22'),
(216, '5.127.61.62', 1, '2018-11-29 11:56:45'),
(217, '5.216.234.185', 1, '2018-11-29 13:59:00'),
(218, '5.219.164.14', 1, '2018-11-29 14:31:40'),
(219, '31.56.98.58', 1, '2018-11-29 15:04:39'),
(220, '89.198.79.220', 1, '2018-11-29 15:50:40'),
(221, '145.239.0.173', 1, '2018-11-29 16:01:32'),
(222, '5.123.40.217', 1, '2018-11-29 16:49:58'),
(223, '5.123.42.246', 1, '2018-11-29 17:03:57'),
(224, '192.119.167.80', 1, '2018-11-29 17:20:59'),
(225, '89.187.187.100', 1, '2018-11-29 17:32:20'),
(226, '5.214.31.203', 1, '2018-11-29 18:01:15'),
(227, '31.2.135.233', 1, '2018-11-29 18:33:59'),
(228, '5.116.107.24', 1, '2018-11-29 20:10:09'),
(229, '5.126.99.150', 1, '2018-11-29 20:41:24'),
(230, '2.182.154.77', 1, '2018-11-29 21:13:21'),
(231, '91.251.227.39', 1, '2018-11-29 22:16:24'),
(232, '5.127.119.210', 1, '2018-11-29 22:21:15'),
(233, '159.89.227.68', 1, '2018-11-30 00:31:30'),
(234, '5.120.234.0', 1, '2018-11-30 01:33:55'),
(235, '5.121.158.12', 1, '2018-11-30 02:58:59'),
(236, '5.239.115.1', 1, '2018-11-30 05:12:39'),
(237, '69.194.93.39', 1, '2018-11-30 06:09:02'),
(238, '5.121.70.133', 1, '2018-11-30 06:10:38'),
(239, '89.198.22.251', 1, '2018-11-30 07:05:19'),
(240, '5.115.199.107', 1, '2018-11-30 07:16:06'),
(241, '5.117.164.252', 1, '2018-11-30 08:42:12'),
(242, '5.219.11.214', 1, '2018-11-30 09:26:41'),
(243, '207.180.224.62', 1, '2018-11-30 09:32:46'),
(244, '185.208.148.8', 1, '2018-11-30 09:37:02'),
(245, '5.233.190.24', 1, '2018-11-30 09:51:01'),
(246, '95.82.77.156', 1, '2018-11-30 10:10:47'),
(247, '51.15.112.119', 1, '2018-11-30 10:43:13'),
(248, '5.116.123.27', 1, '2018-11-30 11:04:59'),
(249, '5.127.159.100', 1, '2018-11-30 11:53:25'),
(250, '5.212.91.71', 1, '2018-11-30 12:22:25'),
(251, '5.126.47.101', 1, '2018-11-30 12:42:57'),
(252, '5.115.107.255', 1, '2018-11-30 12:50:59'),
(253, '83.122.141.47', 1, '2018-11-30 13:11:53'),
(254, '68.183.119.189', 1, '2018-11-30 14:20:49'),
(255, '2.187.72.158', 1, '2018-11-30 16:57:01'),
(256, '5.116.174.99', 1, '2018-11-30 17:10:08'),
(257, '5.117.63.136', 1, '2018-11-30 20:05:26'),
(258, '185.126.14.186', 1, '2018-12-01 05:25:34'),
(259, '2.178.37.177', 1, '2018-12-01 05:31:03'),
(260, '5.74.108.135', 1, '2018-12-01 05:49:23'),
(261, '37.254.225.45', 1, '2018-12-01 06:48:34'),
(262, '128.199.225.14', 1, '2018-12-01 07:26:53'),
(263, '5.212.18.179', 1, '2018-12-01 09:10:25'),
(264, '5.121.72.214', 1, '2018-12-01 09:16:38'),
(265, '192.119.167.206', 1, '2018-12-01 11:26:18'),
(266, '46.224.165.242', 1, '2018-12-01 18:19:49'),
(267, '31.58.17.16', 1, '2018-12-01 20:47:47'),
(268, '140.82.25.151', 1, '2018-12-02 00:39:48'),
(269, '5.123.245.77', 1, '2018-12-02 06:39:01'),
(270, '89.33.101.223', 1, '2018-12-02 06:45:17'),
(271, '5.121.150.211', 1, '2018-12-02 09:17:39'),
(272, '5.116.234.227', 1, '2018-12-02 12:59:32'),
(273, '185.126.13.193', 1, '2018-12-02 14:50:26'),
(274, '5.215.205.153', 1, '2018-12-02 17:10:09'),
(275, '158.58.72.87', 1, '2018-12-02 21:13:13'),
(276, '5.215.65.217', 1, '2018-12-04 00:30:43'),
(277, '5.216.176.214', 1, '2018-12-04 22:07:31'),
(278, '5.125.89.249', 1, '2018-12-05 09:37:14'),
(279, '5.217.5.213', 1, '2018-12-05 20:53:54'),
(280, '5.123.2.224', 1, '2018-12-06 05:55:10'),
(281, '5.123.236.96', 1, '2018-12-06 06:45:48'),
(282, '83.122.221.49', 1, '2018-12-06 11:52:41'),
(283, '95.174.64.210', 1, '2018-12-06 12:18:07'),
(284, '188.211.40.96', 1, '2018-12-07 08:40:40'),
(285, '5.217.176.186', 1, '2018-12-09 00:17:23'),
(286, '5.217.218.189', 1, '2018-12-10 14:03:47'),
(287, '2.185.140.131', 1, '2018-12-12 16:21:31'),
(288, '5.216.50.65', 1, '2018-12-12 16:41:58'),
(289, '5.121.58.20', 1, '2018-12-14 08:51:44'),
(290, '51.38.82.193', 1, '2018-12-14 19:27:28'),
(291, '5.124.0.153', 1, '2018-12-16 08:17:23'),
(292, '37.255.1.179', 1, '2018-12-17 14:59:40'),
(293, '158.58.19.119', 1, '2018-12-17 22:26:04'),
(294, '185.215.148.22', 1, '2018-12-22 01:07:28'),
(295, '2.176.178.194', 1, '2018-12-27 21:32:34'),
(296, '145.239.6.240', 1, '2018-12-29 03:11:38'),
(297, '167.99.134.122', 1, '2019-01-16 13:08:09'),
(298, '190.2.152.101', 1, '2019-01-21 22:11:48'),
(299, '5.115.149.205', 1, '2019-01-27 12:49:17'),
(300, '54.36.118.235', 1, '2019-01-29 23:40:17'),
(301, '151.233.81.127', 1, '2019-02-08 07:01:14'),
(302, '5.127.152.23', 1, '2019-02-24 18:14:36'),
(303, '5.127.40.95', 1, '2019-02-25 18:04:31'),
(304, '5.116.98.34', 1, '2019-03-05 13:39:45'),
(305, '159.65.174.74', 1, '2019-03-18 14:23:07'),
(306, '89.235.125.139', 1, '2019-09-29 15:29:13');

-- --------------------------------------------------------

--
-- Table structure for table `u_comment`
--

CREATE TABLE `u_comment` (
  `id` int(11) NOT NULL,
  `uname` text COLLATE utf8_persian_ci NOT NULL,
  `uid` text COLLATE utf8_persian_ci NOT NULL,
  `c_text` text COLLATE utf8_persian_ci,
  `c_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `list_user`
--
ALTER TABLE `list_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `l_ads`
--
ALTER TABLE `l_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `l_insta`
--
ALTER TABLE `l_insta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `l_tele`
--
ALTER TABLE `l_tele`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_list`
--
ALTER TABLE `pay_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `req_ads`
--
ALTER TABLE `req_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sef_insta`
--
ALTER TABLE `sef_insta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sef_tele`
--
ALTER TABLE `sef_tele`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hispay`
--
ALTER TABLE `tbl_hispay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ip`
--
ALTER TABLE `tbl_ip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_comment`
--
ALTER TABLE `u_comment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `list_user`
--
ALTER TABLE `list_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=725;

--
-- AUTO_INCREMENT for table `l_ads`
--
ALTER TABLE `l_ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `l_insta`
--
ALTER TABLE `l_insta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `l_tele`
--
ALTER TABLE `l_tele`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pay_list`
--
ALTER TABLE `pay_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `req_ads`
--
ALTER TABLE `req_ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sef_insta`
--
ALTER TABLE `sef_insta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sef_tele`
--
ALTER TABLE `sef_tele`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tbl_hispay`
--
ALTER TABLE `tbl_hispay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_ip`
--
ALTER TABLE `tbl_ip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `u_comment`
--
ALTER TABLE `u_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
