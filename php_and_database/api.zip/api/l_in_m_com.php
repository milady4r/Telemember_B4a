
<?php
include 'db.php';

$username= $_GET['username'];
$uid= $_GET['uid'];
$comment= $_GET['comment'];
$commentid= $_GET['commentid'];


$pic= $_GET['pic'];
$id_post= $_GET['id_post'];
$sefaresh= $_GET['sefaresh'];
$done= $_GET['done'];
$show= $_GET['show'];
$c_id= $_GET['c_id'];

 mysql_query("SET CHARACTER SET utf8mb4");
    mysql_query("SET NAMES utf8mb4");
    
    
    $q = mysql_query("INSERT INTO u_comment (`id`, `uname`, `uid`, `c_text`, `c_id`) VALUES (NULL, '$username', '$uid', '$comment', '$commentid')");
        $count = mysql_num_rows($q);
?>