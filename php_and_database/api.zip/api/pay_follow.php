 <?php



include 'db.php';

		
		
		$q="SELECT * FROM pay_list where x like 'follow'";
			
		$res1=mysql_query($q);
	
		$d2array = array();
		while(($row = mysql_fetch_assoc($res1)))
		$d2array[] = $row;
	
	
	
		if($d2array){
			
			echo json_encode($d2array);	
		}



?>