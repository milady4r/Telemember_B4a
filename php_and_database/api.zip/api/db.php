
<?php
$con = mysql_connect("localhost","telegra3_ifu","milad74ehem1234");

mysql_query("SET character_set_results=utf8,character_set_client=utf8,character_set_connection=utf8, character_set_database=utf8,character_set_server=utf8",$con);

mysql_select_db("telegra3_instafollow", $con)
?>