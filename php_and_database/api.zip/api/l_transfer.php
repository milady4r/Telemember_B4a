 <?php

$uname= $_GET['uname'];
$uid= $_GET['uid'];
$target= $_GET['target'];
$n_coins=$_GET['n_coin'];
$type_coin=$_GET['type_coin'];

include 'db.php';

         
		if (isset($uname)) {
		          $db_s = mysql_query("SELECT user FROM list_user WHERE user='$target'");
                  $num_asss = mysql_num_rows($db_s);
		          if ($num_asss>0){
		    
		                 if ($type_coin=="1"){
					   
						 $db_b = mysql_query("UPDATE list_user SET coin_l=coin_l-$n_coins WHERE user='$uname' ");
						 
						 $db_b = mysql_query("UPDATE list_user SET coin_l=coin_l+$n_coins WHERE user='$target'");
						 
                                 echo " با موفقیت انتقال یافت";
		                 }
		                 
		                 if ($type_coin=="2"){
					   
						 $db_b = mysql_query("UPDATE list_user SET coin_c=coin_c-$n_coins WHERE user='$uname' ");
						 
						 $db_b = mysql_query("UPDATE list_user SET coin_c=coin_c+$n_coins WHERE user='$target'");
						 
                                 echo " با موفقیت انتقال یافت";
		                 }
		                 
		                 
		                 if ($type_coin=="3"){
					   
						 $db_b = mysql_query("UPDATE list_user SET coin_f=coin_f-$n_coins WHERE user='$uname' ");
						 
						 $db_b = mysql_query("UPDATE list_user SET coin_f=coin_f+$n_coins WHERE user='$target'");
						 
                                 echo " با موفقیت انتقال یافت";
		                 }
						 
					 }else {
					     echo "کاربر یافت نشد";
					 }
					 
		    
		}else{
		    echo'Erorr';
		}
		
		
	

?>