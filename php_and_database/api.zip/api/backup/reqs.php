
<?php


include 'db.php';
//include_once("TimeAgo.class.php");
date_default_timezone_set("Asia/tehran");

define('API_KEY','68a04945eb02970e2e8d15266fc256f7295da123e123f44b88f09d594a5902df');

function make_header($req){
    $req = str_replace("'",'"',$req);
    $sig = hash_hmac('sha256', $req, '68a04945eb02970e2e8d15266fc256f7295da123e123f44b88f09d594a5902df', false);
   // echo $sig;
    return 'ig_sig_key_version=5&signed_body='.$sig.'.'.str_replace("+","%20",str_replace("-","%2D",urlencode($req)));
    
        
};




$favcolor =$_GET["req"];
$favcolor =$_POST["req"];
switch ($favcolor) {
    case "auth":
       // echo "Your favorite color is red!";
        
       $a=make_header("milad");
       foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  // echo "$name: $value\n<BR/>";
                 //$hash="Authorization: Basic " . base64_encode("$user:milad74");
                // if(isset($_POST["user"],$_POST["pass"],$_POST["email"],$_POST["f_name"],$_POST["city"],$_POST["phone"],$_POST["device"],$_POST["socials"],$_POST["ip"])){
                     
                     $user=$_POST["user"];$pass=$_POST["pass"];$email=$_POST["email"];$f_name=$_POST["f_name"];$city=$_POST["city"];
                     $phone=$_POST["phone"];$device=$_POST["device"];$socials=$_POST["socials"];$ip=$_POST["ip"];
                     //$user="miladaaaaaa";
                     //$pass="123456";
                     $q = mysql_query("SELECT user FROM auth WHERE user = '$user'  ");
                  $count = mysql_num_rows($q);
                   
                  if ($count == 0)
                  {          

$res = mysql_query("INSERT INTO `auth` (`id`, `user`, `pass`, `email`, `f_name`, `city`, `phone`, `device`, `token`, `ip`, `vip`, `time`) VALUES (NULL, '$user', '$pass', '$email', '$f_name', '$city', '$phone', '$device', '$token', '$ip', '0', CURRENT_TIMESTAMP)");
                   
                   
                   
                   $return_arr = array();
    $fetch = mysql_query("SELECT * FROM auth WHERE user = '$user' "); 
$hash="Basic " . base64_encode("$user:$pass");
    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['auth'] = "ok";
        $row_array['token'] = $hash;
        $row_array['id'] = $row['id'];
        $row_array['user'] = $row['user'];
        $row_array['f_name'] = $row['f_name'];
        $row_array['email'] = $row['email'];
        $row_array['instagram'] = $row['instagram'];
        $row_array['telegram'] = $row['telegram'];
        $row_array['ads'] = $row['ads'];
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{       
                  
                     print '{"auth":"false","error_code":"1"}'; 
                  }  
                     
                 ///} if isset
                  
                  
               } ////useragent
                   
           // break;
           }
           
    
    
}
      //  print $a;
        break;
    case "login":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               
              
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                 
                // if(isset($_POST["user"],$_POST["pass"],$_POST["email"],$_POST["f_name"],$_POST["city"],$_POST["phone"],$_POST["device"],$_POST["socials"],$_POST["ip"])){
                     
                     $user=$_POST["user"];$pass=$_POST["pass"];$email=$_POST["email"];$f_name=$_POST["f_name"];$city=$_POST["city"];
                     $phone=$_POST["phone"];$device=$_POST["device"];$socials=$_POST["socials"];$ip=$_POST["ip"];
                     ///$user="milad";
                    // $pass="123456";
                     $q = mysql_query("SELECT * FROM auth WHERE user = '$user' and pass='$pass' ");
                  $count = mysql_num_rows($q);
                   
                  if ($count == 1){
                      $return_arr = array();
    $fetch = mysql_query("SELECT * FROM auth WHERE user = '$user'"); 
$hash="Basic " . base64_encode("$user:$pass");
    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['auth'] = "ok";
        $row_array['token'] = $hash;
        $row_array['id'] = $row['id'];
        $row_array['user'] = $row['user'];
        $row_array['f_name'] = $row['f_name'];
        $row_array['email'] = $row['email'];
        $row_array['instagram'] = $row['instagram'];
        $row_array['telegram'] = $row['telegram'];
        $row_array['ads'] = $row['ads'];
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                  }
                    
                  else{                  
                     print '{"login":"false","error_code":"2"}'; 
                  }  
                     
                 ///} if isset
                  
                  
               }
                   
           // break;
           }
           
    
    
}
        
        
        
        
        break;
    case "iuser":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  // echo "$name: $value\n<BR/>";
                 //$hash="Authorization: Basic " . base64_encode("$user:milad74");
                // if(isset($_POST["user"],$_POST["pass"],$_POST["email"],$_POST["f_name"],$_POST["city"],$_POST["phone"],$_POST["device"],$_POST["socials"],$_POST["ip"])){
                     
                     $uid=$_POST["uid"];$userid=$_POST["userid"];$username=$_POST["username"];$pass=$_POST["pass"];$c_f=$_POST["c_f"];
                     $c_m=$_POST["c_m"];$pic=$_POST["pic"];$phone=$_POST["phone"];$token=$_POST["token"];
                     //$username="milad";
                     //$userid="12345678";
                     $uid=1;
                     $q = mysql_query("SELECT * FROM l_insta WHERE userid = '$userid' ");
                  $count = mysql_num_rows($q);
                   
                  if ($count == 0)
                  {      
                      ///////////////////  make xml
                      
                      $doc = new DOMDocument('1.0');

                      $doc->formatOutput = true;

                      $root = $doc->createElement('media');
                      $root = $doc->appendChild($root);

                      $title = $doc->createElement('id');
                      $title = $root->appendChild($title);

                      $text = $doc->createTextNode('start');
                      $text = $title->appendChild($text);
                      $doc->saveXML();
                      $doc->saveXML($title);
                      $doc->save('medias/'.$userid.'.xml');

                    
                      //////////////// end xml

$res = mysql_query("INSERT INTO `l_insta` (`id`, `uid`, `userid`, `username`, `pass`, `c_f`, `c_m`, `pic`, `phone`, `token`, `time`) VALUES (NULL, '$uid', '$userid', '$username', '$pass', '15', '15', '$pic', '$phone', '$token', CURRENT_TIMESTAMP)");
                   
                   
                   
                   $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_insta WHERE userid = '$userid'"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['addcc'] = "ok";
        $row_array['uid'] = $uid;
        $row_array['id'] = $row['id'];
        $row_array['userid'] = $row['userid'];
        $row_array['username'] = $row['username'];
        $row_array['c_f'] = $row['c_f'];
        $row_array['c_m'] = $row['c_m'];
        $row_array['pic'] = $row['pic'];
 
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{       
                      $sqls = "UPDATE l_insta SET pass='$pass',username='$username' WHERE userid='$userid' ";
                      $res = mysql_query($sqls);
                     print '{"inuser":"false","error_code":"3"}'; 
                  }  
                     
                 ///} if isset
                  
                  
               }
                   
           // break;
           }
           
    
    
}
        
        
        
        break;
    case "tuser":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  // echo "$name: $value\n<BR/>";
                 //$hash="Authorization: Basic " . base64_encode("$user:milad74");
                // if(isset($_POST["user"],$_POST["pass"],$_POST["email"],$_POST["f_name"],$_POST["city"],$_POST["phone"],$_POST["device"],$_POST["socials"],$_POST["ip"])){
                     
                     $uid=$_POST["uid"];$userid=$_POST["userid"];$username=$_POST["username"];$pass=$_POST["pass"];$c_ch=$_POST["c_ch"];
                     $c_m=$_POST["c_m"];$pic=$_POST["pic"];$phone=$_POST["phone"];
                     $username="milad";
                     $userid="12345678";
                     $q = mysql_query("SELECT * FROM l_tele WHERE userid = '$userid' ");
                  $count = mysql_num_rows($q);
                   
                  if ($count == 0)
                  {          

$res = mysql_query("INSERT INTO `l_tele` (`id`, `uid`, `userid`, `username`, `first_last`, `phone`, `c_ch`, `c_m`, `times`) VALUES (NULL, '$uid', '$userid', '$username', '$first_last', '$phone', '$c_ch', '$c_m', CURRENT_TIMESTAMP)");
                   
                   
                   
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_tele WHERE userid = '$userid'"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['addcc'] = "ok";
        $row_array['uid'] = $row['uid'];
        $row_array['id'] = $row['id'];
        $row_array['userid'] = $row['userid'];
        $row_array['username'] = $row['username'];
        $row_array['c_ch'] = $row['c_ch'];
        $row_array['c_m'] = $row['c_m'];
        $row_array['first_last'] = $row['first_last'];
 
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"inuser":"false","error_code":"4"}'; 
                  }  
                     
                 ///} if isset
                  
                  
               }
                   
           // break;
           }
           
    
    
}
        
        
        
        
        break;
    case "get_insta":
        
                
         foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$target=$_POST["target"];$start=$_POST["start"];
                   $finish=$_POST["finish"];$status=$_POST["status"];
                                    
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM sef_insta WHERE start<finish or start=finish and types = '$types' and status=0 ORDER BY rand() LIMIT 5"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        $idpost=$row['id'];
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['userid'] = $row['userid'];
        $row_array['types'] = $row['types'];
        $row_array['target'] = $row['target'];
        $row_array['start'] = $row['start'];
        $row_array['finish'] = $row['finish'];
        $row_array['status'] = $row['status'];
        $row_array['token'] = $row['token'];
        
         if ($types=="2"){
              $fetcha = mysql_query("SELECT * FROM u_comment WHERE c_id = '$idpost' ORDER BY rand() LIMIT 1"); 

         while ($rowa = mysql_fetch_array($fetcha, MYSQL_ASSOC)) {
          
              $row_array['comtext'] = $rowa['c_text'];
        
             }
            
        }
        
        array_push($return_arr,$row_array);
    }
        echo json_encode($return_arr);           
               }
           }
         }
                   
 
        break;
        
        
         case "get_sef":
        
                
         foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$target=$_POST["target"];$start=$_POST["start"];
                   $finish=$_POST["finish"];$status=$_POST["status"];
                                    
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM sef_insta WHERE userid='$userid' "); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        $idpost=$row['id'];
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['userid'] = $row['userid'];
        $row_array['types'] = $row['types'];
        $row_array['target'] = $row['target'];
        $row_array['start'] = $row['start'];
        $row_array['finish'] = $row['finish'];
        $row_array['status'] = $row['status'];
        $row_array['token'] = $row['token'];
        
         if ($types=="2"){
              $fetcha = mysql_query("SELECT * FROM u_comment WHERE c_id = '$idpost' ORDER BY rand() LIMIT 1"); 

         while ($rowa = mysql_fetch_array($fetcha, MYSQL_ASSOC)) {
          
              $row_array['comtext'] = $rowa['c_text'];
        
             }
            
        }
        
        array_push($return_arr,$row_array);
    }
        echo json_encode($return_arr);           
               }
           }
         }
                   
 
        break;
        
        
        
        
    case "get_telegram":
        
               
         foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$chat_id=$_POST["chat_id"];$msg_id=$_POST["msg_id"];
                   $finish=$_POST["finish"];$njob=$_POST["njob"];$token=$_POST["token"];
                  
                                    
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM sef_tele WHERE types = '$types' ORDER BY rand() LIMIT 5"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['userid'] = $row['userid'];
        $row_array['types'] = $row['types'];
        $row_array['target'] = $row['target'];
        $row_array['start'] = $row['start'];
        $row_array['finish'] = $row['finish'];
        $row_array['njob'] = $row['njob'];
        $row_array['status'] = $row['status'];
        $row_array['token'] = $row['token'];
        
        array_push($return_arr,$row_array);
    }
            echo json_encode($return_arr);       
               }
           }
         }
        
        
        
    break;        
        
    case "get_ads":
        
               
         foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   $uid=$_POST["uid"];$types=$_POST["types"];$description=$_POST["description"];$urls=$_POST["url"];$num_see=$_POST["num_see"];
                   $num_users=$_POST["num_users"];$is_ads=$_POST["is_ads"];$is_vip=$_POST["is_vip"];
                   $socia=$_POST["socia"];$is_ok=$_POST["is_ok"];$price=$_POST["price"];$pic=$_POST["pic"];$t_update=$_POST["t_update"]; 
                   $t_make=$_POST["t_make"]; $t1=$_POST["t1"]; $t2=$_POST["t2"];
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_ads ORDER BY rand() LIMIT 5"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['description'] = $row['description'];
        $row_array['url'] = $row['url'];
        $row_array['num_see'] = $row['num_see'];
        $row_array['num_users'] = $row['num_users'];
        $row_array['is_ads'] = $row['is_ads'];
        $row_array['is_vip'] = $row['is_vip'];
        $row_array['socia'] = $row['socia'];
        $row_array['is_ok'] = $row['is_ok'];
        $row_array['price'] = $row['price'];
        $row_array['pic'] = $row['pic'];
        $row_array['t_update'] = $row['t_update'];
        $row_array['t_make'] = $row['t_make'];
        $row_array['t1'] = $row['t1'];
        $row_array['t2'] = $row['t2'];
       
        
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
                   
               }
           }
         }
        
        
        
        break;        
    
    case "i_sef":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$target=$_POST["target"];$start=$_POST["start"];
                   $finish=$_POST["finish"];$status=$_POST["status"];
                    $tokenn=random_string(15); 
                    
                  if($types=="1" or $types=="2" or $types=="4"){
                      $coins=$finish * 3;
                      $q = mysql_query("SELECT * FROM l_insta WHERE uid = '$uid' and userid = '$userid'  ");
                      //$count = mysql_num_rows($q);
                      while ($row = mysql_fetch_array($q, MYSQL_ASSOC)) {
                           $c_m = $row['c_m'];
                           $c_f = $row['c_f'];
                           
                           
                           if($coins<$c_m){
                               
                               $up=mysql_query("UPDATE l_insta SET c_m= c_m-'$coins' WHERE userid='$userid'");
                               $count=0;
                               
                                 if($types=="2"){
                                     
                                  $ac = json_decode($target,ture);
                                  $target=$ac['target'];
                                  $sizes=$ac['size'];
                                  $texs=$ac['texts'];
                                  
                                //  print $stat.' '.$sizes.'<br>';
                                //  print $texs.'<br>';
          
                            
                                 }
                           }
                           
                      }
                  }
                  
                  
                  
                  if($types=="3"){
                      $coins=$finish * 4;
                      
                      $q = mysql_query("SELECT * FROM l_insta WHERE uid = '$uid' and userid = '$userid'  ");
                      //$count = mysql_num_rows($q);
                      while ($row = mysql_fetch_array($q, MYSQL_ASSOC)) {
                           $c_m = $row['c_m'];
                           $c_f = $row['c_f'];
                           
                           
                           if($coins<$c_f){
                               
                               $up=mysql_query("UPDATE l_insta SET c_f= c_f-'$coins' WHERE userid='$userid'");
                               $count=0;
                               
                           }
                           
                      }
                      
                      
                  } 
                  
                  if ($count == 0)
                  {          

$res = mysql_query("INSERT INTO `sef_insta` (`id`, `uid`, `userid`, `types`, `target`, `start`, `finish`, `status`, `token`, `times`) VALUES (NULL, '$uid', '$userid', '$types', '$target', '0', '$finish', '0', '$tokenn', CURRENT_TIMESTAMP)");
                   
 
    $fetchq = mysql_query("SELECT * FROM sef_insta WHERE types = '$types' and target='$target' and token='$tokenn' "); 

    while ($rowq = mysql_fetch_array($fetchq, MYSQL_ASSOC)) {
                                  
                                  
                                  $idcom=$rowq['id'];
                           if($types=="2"){
                             $aca = json_decode($texs,ture);
                                  
                                  for ($x = 0; $x <= $sizes; $x++) {
                                   $sta=$aca[$x];
                                   $res = mysql_query("INSERT INTO `u_comment` (`id`, `uname`, `uid`, `c_text`, `c_id`) VALUES (NULL, '$userid', '1', '$sta', '$idcom')");
                                  } 
                                                    }
        $ttypes=$rowq['types'];
        $ttarget=$rowq['target'];
        $tid=$rowq['id'];
        sendGCM($ttypes,$ttarget,$tid);                         
    }
    
                   
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_insta WHERE userid = '$userid'"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['result'] = "ok";
        $row_array['uid'] = $uid;
        $row_array['id'] = $row['id'];
        $row_array['userid'] = $row['userid'];
        $row_array['username'] = $row['username'];
        $row_array['c_f'] = $row['c_f'];
        $row_array['c_m'] = $row['c_m'];
        $row_array['pic'] = $row['pic'];
 
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"i_sef":"false","error_code":"3","coin":"samll"}'; 
                  }  
                     

                 
               }

           }
           
}
        
       
        break;
    
     case "t_sef":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$chat_id=$_POST["chat_id"];$msg_id=$_POST["msg_id"];
                   $finish=$_POST["finish"];$njob=$_POST["njob"];$token=$_POST["token"];
                    $tokenn=random_string(15); 
                    
                  if($types=="1"|$types=="2"|$types=="3"){
                      $coins=$finish * 3;
                      $q = mysql_query("SELECT * FROM l_tele WHERE id = '$uid' and userid = '$userid'  ");
                      //$count = mysql_num_rows($q);
                      while ($row = mysql_fetch_array($q, MYSQL_ASSOC)) {
                           $c_m = $row['c_m'];
                             $c_ch = $row['c_ch'];
                           
                           
                           if($coins>$c_m){
                               
                               $up=mysql_query("UPDATE l_tele SET c_m= '$coins'-c_m WHERE userid='$userid'");
                               $count=0;
                               
                           }else{
                               $count=1;
                           }
                           
                      }
                  }
                  
                  if($types=="4"){
                      $coins=$finish * 4;
                      
                      $q = mysql_query("SELECT * FROM l_tele WHERE id = '$uid' and userid = '$userid'  ");
                      //$count = mysql_num_rows($q);
                      while ($row = mysql_fetch_array($q, MYSQL_ASSOC)) {
                           $c_m = $row['c_m'];
                           $c_ch = $row['c_ch'];
                           
                           
                           if($coins>$c_f){
                               
                               $up=mysql_query("UPDATE l_tele SET c_ch= '$coins'-c_ch WHERE userid='$userid'");
                               $count=0;
                               
                           }else{
                               $count=1;
                           }
                           
                      }
                      
                      
                  } 
                  
                  if ($count == 0)
                  {          
                                            
$res = mysql_query("INSERT INTO `sef_tele` (`id`, `uid`, `userid`, `chat_id`, `msg_id`, `start`, `finish`, `njob`, `types`, `token`, `times`) VALUES (NULL, '$uid', '$userid', '$chat_id', '$msg_id', '0', '$finish', '$njob', '$types', '$tokenn', CURRENT_TIMESTAMP");
                   
                   
     $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_tele WHERE userid = '$userid'"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['result'] = "ok";
        $row_array['uid'] = $row['uid'];
        $row_array['id'] = $row['id'];
        $row_array['userid'] = $row['userid'];
        $row_array['username'] = $row['username'];
        $row_array['c_ch'] = $row['c_ch'];
        $row_array['c_m'] = $row['c_m'];
        $row_array['first_last'] = $row['first_last'];
 
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"i_sef":"false","error_code":"3","coin":"samll"}'; 
                  }  
                     

                 
               }

           }
           
    
    
}
        
        
        
        break;
        
         case "a_sef":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
                                  
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  
                   $uid=$_POST["uid"];$types=$_POST["types"];$description=$_POST["description"];$url=$_POST["url"];$num_see=$_POST["num_see"];
                   $num_users=$_POST["num_users"];$is_ads=$_POST["is_ads"];$is_vip=$_POST["is_vip"];
                   $socia=$_POST["socia"];$is_ok=$_POST["is_ok"];$price=$_POST["price"];$pic=$_POST["pic"];$t_update=$_POST["t_update"]; 
                   $t_make=$_POST["t_make"]; $t1=$_POST["t1"]; $t2=$_POST["t2"];$username=$_POST["username"];
                    $tokenn=random_string(15); 
                    
                  
                  
                  $q = mysql_query("SELECT * FROM l_tele WHERE id = '$uid' and username = '$username' or url='$url' ");
                   $count = mysql_num_rows($q);
                  
                  if ($count == 0)
                  {          
                                            
$res = mysql_query("INSERT INTO `l_ads` (`id`, `uid`, `types`, `username`, `description`, `url`, `num_see`, `num_users`, `is_ads`, `is_vip`, `socia`, `is_ok`, `price`, `pic`, `t1`, `t2`, `t_update`, `t_make`) VALUES
(NULL, '$uid', '$types', '$username', '$description', '$url', '$num_see', '$num_users', '$is_ads', '$is_vip', '$socia', '$is_ok', '$price', '$pic', '$t1', '$t2', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");

                   
     $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_ads rand() LIMIT 5"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['description'] = $row['description'];
        $row_array['url'] = $row['url'];
        $row_array['num_see'] = $row['num_see'];
        $row_array['num_users'] = $row['num_users'];
        $row_array['is_ads'] = $row['is_ads'];
        $row_array['is_vip'] = $row['is_vip'];
        $row_array['socia'] = $row['socia'];
        $row_array['is_ok'] = $row['is_ok'];
        $row_array['price'] = $row['price'];
        $row_array['pic'] = $row['pic'];
        $row_array['t_update'] = $row['t_update'];
        $row_array['t_make'] = $row['t_make'];
        $row_array['t1'] = $row['t1'];
        $row_array['t2'] = $row['t2'];
       
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"i_sef":"false","error_code":"3","coin":"samll"}'; 
                  }  
                     

                 
               }

           }
           
    
    
}
        
         break;
    ///////////////////////////////////////////////////////////////////////////   get myacc ***************************************************************************
        case "get_acci":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$target=$_POST["target"];$start=$_POST["start"];
                   $finish=$_POST["finish"];$status=$_POST["status"];
                   $tokenn=random_string(15); 
                    
                      $q = mysql_query("SELECT * FROM l_insta WHERE id = '$uid' and userid = '$userid'  ");
                      $count = mysql_num_rows($q);

                  
                  if ($count == 0)
                  {          

                  
    $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_insta WHERE userid = '$userid'"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['result'] = "ok";
        $row_array['uid'] = $uid;
        $row_array['id'] = $row['id'];
        $row_array['userid'] = $row['userid'];
        $row_array['username'] = $row['username'];
        $row_array['c_f'] = $row['c_f'];
        $row_array['c_m'] = $row['c_m'];
        $row_array['pic'] = $row['pic'];
 
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"i_sef":"false","error_code":"3","user":"samll"}'; 
                  }  
                     

                 
               }

           }
           
}
        
       
        break;
    
     case "get_acct":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$chat_id=$_POST["chat_id"];$msg_id=$_POST["msg_id"];
                   $finish=$_POST["finish"];$njob=$_POST["njob"];$token=$_POST["token"];
                    $tokenn=random_string(15); 
                    
                    $q = mysql_query("SELECT * FROM l_tele WHERE id = '$uid' and userid = '$userid'  ");
                    $count = mysql_num_rows($q);
                    
                 
                  
                  if ($count == 0)
                  {          
                  
     $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_tele WHERE userid = '$userid'"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['result'] = "ok";
        $row_array['uid'] = $row['uid'];
        $row_array['id'] = $row['id'];
        $row_array['userid'] = $row['userid'];
        $row_array['username'] = $row['username'];
        $row_array['c_ch'] = $row['c_ch'];
        $row_array['c_m'] = $row['c_m'];
        $row_array['first_last'] = $row['first_last'];
 
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"i_sef":"false","error_code":"3","user":"samll"}'; 
                  }  
                     

                 
               }

           }
           
    
    
}
        
        
        
        break;
        
         case "get_acca":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
                                  
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                  
                   $uid=$_POST["uid"];$types=$_POST["types"];$description=$_POST["description"];$url=$_POST["url"];$num_see=$_POST["num_see"];
                   $num_users=$_POST["num_users"];$is_ads=$_POST["is_ads"];$is_vip=$_POST["is_vip"];
                   $socia=$_POST["socia"];$is_ok=$_POST["is_ok"];$price=$_POST["price"];$pic=$_POST["pic"];$t_update=$_POST["t_update"]; 
                   $t_make=$_POST["t_make"]; $t1=$_POST["t1"]; $t2=$_POST["t2"];$username=$_POST["username"];
                    $tokenn=random_string(15); 
                    
                  
                  
                  $q = mysql_query("SELECT * FROM l_tele WHERE id = '$uid' and username = '$username' or url='$url' ");
                   $count = mysql_num_rows($q);
                  
                  if ($count == 0)
                  {          
 
     $return_arr = array();
    $fetch = mysql_query("SELECT * FROM l_ads rand() LIMIT 5"); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['description'] = $row['description'];
        $row_array['url'] = $row['url'];
        $row_array['num_see'] = $row['num_see'];
        $row_array['num_users'] = $row['num_users'];
        $row_array['is_ads'] = $row['is_ads'];
        $row_array['is_vip'] = $row['is_vip'];
        $row_array['socia'] = $row['socia'];
        $row_array['is_ok'] = $row['is_ok'];
        $row_array['price'] = $row['price'];
        $row_array['pic'] = $row['pic'];
        $row_array['t_update'] = $row['t_update'];
        $row_array['t_make'] = $row['t_make'];
        $row_array['t1'] = $row['t1'];
        $row_array['t2'] = $row['t2'];
       
        
        array_push($return_arr,$row_array);
    }

    echo json_encode($return_arr);
                   
                  }  
                  else{                  
                     print '{"i_sef":"false","error_code":"3","coin":"samll"}'; 
                  }  
                     

                 
               }

           }
           
    
    
}
        
         break;
    
     case "test1":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
                                  
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   
                   
               }
               
           }
        }
                   
     break;
     case "donereq":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
                                  
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   $userid=$_POST["userid"];$mediaid=$_POST["mediaid"];$typemodule=$_POST["typemodule"];
                   
                   // search and save xml
                   
                   
                   $xml = simplexml_load_file('medias/'.$userid.'.xml');

                  // $product_code = '1213456464684564646';
                   $products = $xml->xpath("/media/id[contains(text(), '$mediaid')]");
                   
                   if(count($products) > 0) {
                       print '{"status":"false","error_code":"4"}';
                      
                       
                   }else{
                      
                   
                   $simp = simplexml_load_file('medias/'.$userid.'.xml'); 
                   $simp->addChild('id', $mediaid);
                   $s = simplexml_import_dom($simp);
                   $s->saveXML('medias/'.$userid.'.xml');
                   
                    
                   
                    
                    if($typemodule=="1"){
                         $up=mysql_query("UPDATE l_insta SET c_m= c_m+2 WHERE userid='$userid'");
                         $up=mysql_query("UPDATE sef_insta SET start= start+1 WHERE target='$mediaid'");
                    }else if($typemodule==2){
                         $up=mysql_query("UPDATE l_insta SET c_f= c_f+4 WHERE userid='$userid'");
                         $up=mysql_query("UPDATE sef_insta SET start= start+1 WHERE target='$mediaid'");
                    }
                    
                    
                    
                    
                     $return_arr = array();
                     $fetch = mysql_query("SELECT * FROM l_insta WHERE userid = '$userid'"); 

                     while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        
                     $row_array['status'] = "true";
                     $row_array['uid'] = $uid;
                     $row_array['id'] = $row['id'];
                     $row_array['userid'] = $row['userid'];
                     $row_array['username'] = $row['username'];
                     $row_array['c_f'] = $row['c_f'];
                     $row_array['c_m'] = $row['c_m'];
                     $row_array['pic'] = $row['pic'];
 
        
                     array_push($return_arr,$row_array);
                     }
                    echo json_encode($return_arr);
                   
                   
                   
                      
                      
                   }
                   
                   
                   
                   
                   
                   
                   // end save as
                   
               }
               
           }
        }
                   
     break;
     case "upsef":
        
        foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
                                  
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                    $ids=$_POST["ids"];
                    $up=mysql_query("UPDATE sef_insta SET start= start+1 WHERE id='$ids'");
                    print '{"status":"true","set":"ok"}';
               }
               
           }
        }
                   
     break;
         case "get_push":
        
                
         foreach (getallheaders() as $name => $value) {
           if($name=="User-Agent"){
               ///print "$value ok<BR/>";
               
              
               if($value=="Dalvik/1.6.0 (Linux; U; Android 4.4.4; SM-A700FD Build/KTU84P)"){
                   $uid=$_POST["uid"];$types=$_POST["types"];$userid=$_POST["userid"];$target=$_POST["target"];$start=$_POST["start"];
                   $finish=$_POST["finish"];$status=$_POST["status"];$ida=$_POST["ida"];
                                    
              $return_arr = array();
    $fetch = mysql_query("SELECT * FROM sef_insta WHERE id='$ida' AND start<finish or start=finish AND status=0 "); 

    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
        $idpost=$row['id'];
        $row_array['id'] = $row['id'];
        $row_array['uid'] = $row['uid'];
        $row_array['userid'] = $row['userid'];
        $row_array['types'] = $row['types'];
        $row_array['target'] = $row['target'];
        $row_array['start'] = $row['start'];
        $row_array['finish'] = $row['finish'];
        $row_array['status'] = $row['status'];
        $row_array['token'] = $row['token'];
        
         if ($types=="2"){
              $fetcha = mysql_query("SELECT * FROM u_comment WHERE c_id = '$idpost' ORDER BY rand() LIMIT 1"); 

         while ($rowa = mysql_fetch_array($fetcha, MYSQL_ASSOC)) {
          
              $row_array['comtext'] = $rowa['c_text'];
        
             }
            
        }
        
        array_push($return_arr,$row_array);
    }
        echo json_encode($return_arr);           
               }
           }
         }
 
        break;
    /////////////////////////////////////////////////////////////////////////// end  get myacc ************************************************************
          
    default:
        echo "Your favorite color is neither red, blue, nor green!";
}


function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
}

function make_base_auth($user, $password) {
  $tok = $user + ':' + $password;
  $hash = Base64.encode($tok);
  return "Basic " + hash;
}


function sendGCM($typ, $targ,$ida) {


    $url = 'https://fcm.googleapis.com/fcm/send';

    $fields = array (
            'to' => '/topics/allusers',
            'data' => array (
                    "types" => $typ,
                    "target" => $targ,
                    "id" => $ida
            )
    );
    $fields = json_encode ( $fields );

    $headers = array (
            'Authorization: key=' . "AIzaSyBYdQgyrihWWvDV4VC4OGEK4u8vsRVg3sY",
            'Content-Type: application/json'
    );

    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_URL, $url );
    curl_setopt ( $ch, CURLOPT_POST, true );
    curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );

    $result = curl_exec ( $ch );
//    echo $result;
    curl_close ( $ch );
}


 ?>